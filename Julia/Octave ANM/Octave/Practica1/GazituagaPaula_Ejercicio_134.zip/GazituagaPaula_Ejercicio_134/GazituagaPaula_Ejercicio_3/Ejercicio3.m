clear all
clc
%Paula Gazituaga Garc�a 29524103S
disp('Paula Gazituaga Garc�a 29524103S')
%Ejercicio 3
A=[1 5 -1 8 3; -1 4 12 6 -9; 0 3 16 -1 -6; 8 1 4 9 -2; 1 2 7 8 0; 15 22 17 -1 5; 23 -7 1 7 9]
R=Householder2iterR(A)